#ifndef OMNIC_QT_H_
#define OMNIC_QT_H_

#include <QRect>

namespace omni {
  namespace qt {
  
  }
}

#endif /* OMNIC_QT_H_
