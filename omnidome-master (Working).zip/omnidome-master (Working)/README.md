Omnidome
========

Fulldome Projection Calibration Software Framework

How to build Omnidome For Windows
=======================

Omnidome uses the Qt Framework and C++14 standard library and language standard.
This repository is forked from Omnidome project for Windows build.

This forked repository has currently been successfully build on Windows 10.

Install Qt 5.14.2 minGW 64 bit via online installer from the website http://www.qt.io.
Qt is supposed to be installed in the home folder.
You can compile Qt with Qt Creator and selecting CMakeLists.txt as project.

Windows Release version has published as 1.1.0
